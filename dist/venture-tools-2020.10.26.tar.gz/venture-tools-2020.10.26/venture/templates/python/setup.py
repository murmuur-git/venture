import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="",
    version="",
    author="",
    description="",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="",
    packages=setuptools.find_packages(),
    python_requires='',
    install_requires=[
        ''
    ],
    package_data={
       '' : [''], # Includes python template
    },
    entry_points = {
        'console_scripts': [
            ''
        ],
    })
